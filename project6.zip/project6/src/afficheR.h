#include <gtk/gtk.h>
typedef struct
{
char jour[30];
char mois[30];
char annee[30];
char nom[30];
char prenom[30];
char heure[30];
}Affiche;

void afficher_affiche(GtkWidget *liste);
