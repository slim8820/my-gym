#include <gtk/gtk.h>
typedef struct
{
int jour;
int mois;
int annee;
}Date;
typedef struct
{
char nom[30];
char prenom[30];
Date dt_co;
char hr_co[30];
}Rendez;
void rendez_vouz(Rendez r);

