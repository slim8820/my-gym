#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <modifier.h>
void modifier(char Nom[],char Prenom[],char Sexe[],int Age,int Poids,int Taille,char Maladiec[],char allergie[],char Notice[])
{
FILE*f;
FILE*f1;
char Nom1[50];
char Prenom1[50];
char Sexe1[50];
int Age1;
int Poids1;
int Taille1;
char Maladiec1[50];
char allergie1[50];
char Notice1[50];
f=fopen("ajouterFM.txt","r");
f1=fopen("fiche.txt","w");
while(fscanf(f,"%s %s %s %d %d %d %s %s %s\n",Nom1,Prenom1,Sexe1,&Age1,&Poids1,&Taille1,Maladiec1,allergie1,Notice1)!=EOF)
{
if(strcmp(Notice,Notice1)==0)
{
fprintf(f1,"%s %s %s %d %d %d %s %s %s\n",Nom,Prenom,Sexe,Age,Poids,Taille,Maladiec,allergie,Notice);
}
else
{
fprintf(f1,"%s %s %s %d %d %d %s %s %s\n",Nom1,Prenom1,Sexe1,Age1,Poids1,Taille1,Maladiec1,allergie1,Notice1);
}
}
fclose(f);
fclose(f1);
remove("ajouterFM.txt");
rename("fiche.txt","ajouterFM.txt");
}












