int supprimer(char x[]);
