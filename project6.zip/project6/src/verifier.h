int verifier(char username[],char password[]);
