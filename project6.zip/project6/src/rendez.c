#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "rendez.h"
#include <gtk/gtk.h>
void rendez_vouz(Rendez r)
{
FILE*f;
f=fopen("rendez.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %d %d %d %s\n",r.nom,r.prenom,r.dt_co.jour,r.dt_co.mois,r.dt_co.annee,r.hr_co);
fclose(f);
}}
