void ajouter(char username[],char password[],int fonction);
