#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "supprimer.h"
int supprimer(char x[])
{
FILE*f;
FILE*f1;
int test=-1;
char Nom[50];
char Prenom[50];
char Sexe[50];
char Age[50];
char Poids[50];
char Taille[50];
char Maladiec[50];
char allergie[50];
char Notice[50];
f=fopen("ajouterFM.txt","r");
f1=fopen("fiche.txt","w");
while(fscanf(f,"%s %s %s %s %s %s %s %s %s\n",Nom,Prenom,Sexe,Age,Poids,Taille,Maladiec,allergie,Notice)!=EOF)
{
if(strcmp(x,Nom)!=0)
{
fprintf(f,"%s %s %s %d %d %d %s %s %s\n",Nom,Prenom,Sexe,Age,Poids,Taille,Maladiec,allergie,Notice);
}
else
{
test=1;
}
}
fclose(f);
fclose(f1);
remove("ajouterFM.txt");
rename("fiche.txt","ajouterFM.txt");
return(test);
}




