#include <gtk/gtk.h>
typedef struct
{
char nom[50];
char prenom[50];
char sexe[50];
char age[50];
char poids[50];
char taille[50];
char regime[50];

}PersonneN;
void afficher_personneN(GtkWidget *liste);


