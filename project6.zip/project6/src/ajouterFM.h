void ajouteFM(char Nom[],char Prenom[],char Sexe[],int Age,int Poids,int Taille,char MaladieC[] ,char allergie[],char Notice[]);
