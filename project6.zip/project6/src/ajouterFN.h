void ajouteFN(char Nom[],char Prenom[],char Sexe[],int Age,int Poids,int Taille,char Regime[]);
