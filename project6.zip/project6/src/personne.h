
#include <gtk/gtk.h>
typedef struct
{
char username[20];
char password[20];
char fonction[20];
}Personne;
void afficher_personne(GtkWidget *liste);

