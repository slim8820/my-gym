void modifier(char Nom[],char Prenom[],char Sexe[],int Age,int Poids,int Taille,char Maladiec[],char allergie[],char Notice[]);
