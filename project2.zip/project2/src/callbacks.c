#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
#include "fonction.h"
#include <string.h>

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"


void
on_button1_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
window1=lookup_widget(button,"window1");
input=lookup_widget(button,"entry1");
strcpy(x,gtk_entry_get_text(GTK_ENTRY(input)));
input2=lookup_widget(button,"entry2");
strcpy(y,gtk_entry_get_text(GTK_ENTRY(input2)));
verif=verifier(x,y);
if( verif==1){
gtk_widget_hide(window1);
window=create_admin();
gtk_widget_show_all(window);}
else if( verif==2){
gtk_widget_hide(window1);
window=create_adherent();
gtk_widget_show_all(window);}
else if( verif==3){
gtk_widget_hide(window1);
window=create_coach();
gtk_widget_show_all(window);}
else if( verif==4){
gtk_widget_hide(window1);
window=create_nutritionniste();
gtk_widget_show_all(window);}
else if( verif==5){
gtk_widget_hide(window1);
window=create_dieteticien();
gtk_widget_show_all(window);}
else if( verif==6){
gtk_widget_hide(window1);
window=create_kine();
gtk_widget_show_all(window);}
else if( verif==-1){
strcpy(ext,"erreur:user name/ password uncorrect");
output=lookup_widget(button,"label8");
gtk_label_set_text(GTK_LABEL(output),ext);}

}


void
on_button3_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

}


void
on_button4_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

}


void
on_button2_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

}


void
on_button5_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *nom;
GtkWidget *prenom;
GtkWidget *age;
GtkWidget *sexe;
GtkWidget *poids;
GtkWidget *taille;
GtkWidget *cin;
GtkWidget *password;

GtkWidget *date_dabonnement;
GtkWidget *jours;
GtkWidget *mois;
GtkWidget *annee;

Date dt_nais;
admin s ;
jours=lookup_widget(objet_graphique,"spinbutton1");
mois=lookup_widget(objet_graphique,"spinbutton2");
annee=lookup_widget(objet_graphique,"spinbutton3");
password=lookup_widget(objet_graphique,"entry9");
cin=lookup_widget(objet_graphique,"entry10");
nom=lookup_widget(objet_graphique,"entry3");
prenom=lookup_widget(objet_graphique,"entry4");
age=lookup_widget(objet_graphique,"entry5");
sexe=lookup_widget(objet_graphique,"entry6");
poids=lookup_widget(objet_graphique,"entry7");
taille=lookup_widget(objet_graphique,"entry8");
s.dt_nais.jours=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jours));
s.dt_nais.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
s.dt_nais.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
strcpy(s.username,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(s.password,gtk_entry_get_text(GTK_ENTRY(password)));
strcpy(s.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(s.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
ajouter(s);
}






