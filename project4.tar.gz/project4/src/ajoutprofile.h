#include <stdlib.h>
#include <string.h>

struct adh
{   
    
    char nom[20];
    char prenom[20];
    char taille[20] ;
    char sexe[20] ;
    char poids[20] ;
    char choix_du_sport [20];

};
typedef struct adh Adh ;

void modifier_adh( Adh a1) ;

