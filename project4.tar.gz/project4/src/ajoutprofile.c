#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "ajoutprofile.h"

void modifier_adh( Adh a1)
{


    FILE *f ;

     f = fopen("adh.txt","a+");
if ( f!=NULL)
{

    fprintf (f,"%s %s %s %s %s %s \n",a1.nom,a1.prenom,a1.taille,a1.sexe,a1.poids,a1.choix_du_sport);
 
    
}
    fclose(f);

}

