#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "login.c"
#include <stdio.h>	
#include <string.h>
#include "ajoutprofile.h"

void
on_button2_clicked                     (GtkButton       *object_graphique,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_button1_clicked                     (GtkWidget *entry,gpointer user_data)
{
 int n=150,check = -1;
    
    char c[50]="wrong user id or password";
    GtkWidget *input1;
    GtkWidget *input2;
    GtkWidget *output1;
    GtkWidget *output2;
    GtkWidget *menu_adherent;
    GtkWidget *login;
    menu_adherent=create_menu_adherent();
    input1=lookup_widget(entry, "entry1");
    input2=lookup_widget(entry, "entry2");
    output1=lookup_widget(entry, "label6");

    char nom[20];
    strcpy(nom,gtk_entry_get_text(GTK_ENTRY(input1)));
    char pass[20];
    strcpy(pass,gtk_entry_get_text(GTK_ENTRY(input2)));
    check = check_user(nom,pass,n);
    if (check==0){
    
    gtk_widget_show(menu_adherent);
    output2=lookup_widget(menu_adherent, "label5");
   
    }else{
    gtk_label_set_text(GTK_LABEL(output1),c);

}
login=lookup_widget(entry,"login");
gtk_widget_hide(login);
}



void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
 
}


void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button4_clicked                     (GtkWidget *entry,gpointer user_data)
{ GtkWidget *profiles;
    GtkWidget *menu_adherent;
    profiles=create_profiles();
    gtk_widget_show(profiles);
    
   
   


menu_adherent=lookup_widget(entry,"menu_adherent");
gtk_widget_hide(menu_adherent);

}


void
on_button6_clicked                     (GtkButton       *entry,
                                        gpointer         user_data)
{ GtkWidget *consulter_votre_coach;
    GtkWidget *profiles;
    consulter_votre_coach=create_consulter_votre_coach();
    gtk_widget_show(consulter_votre_coach);
    
   
   


profiles=lookup_widget(entry,"profiles");
gtk_widget_hide(profiles);

}




void
on_button7_clicked                     (GtkButton       *entry,
                                        gpointer         user_data)
{GtkWidget *consulter_votre_nutri;
    GtkWidget *profiles;
    consulter_votre_nutri=create_consulter_votre_nutri();
    gtk_widget_show(consulter_votre_nutri);
    
   
   


profiles=lookup_widget(entry,"profiles");
gtk_widget_hide(profiles);

}


void
on_button8_clicked                     (GtkButton       *entry,
                                        gpointer         user_data)
{
GtkWidget *consulter_votre_kine;
    GtkWidget *profiles;
    consulter_votre_kine=create_consulter_votre_kine();
    gtk_widget_show(consulter_votre_kine);
    
   
   


profiles=lookup_widget(entry,"profiles");
gtk_widget_hide(profiles);
}


void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button12_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button16_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button15_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button18_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button17_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button19_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button20_clicked                    (GtkWidget *entry,gpointer user_data)
{
  
  GtkWidget *nom;
  GtkWidget *prenom;
  GtkWidget *combo1;
 GtkWidget *taille;
 GtkWidget *poids;
GtkWidget *combo2;

  Adh a;

  nom=lookup_widget(entry,"entry3");
  prenom=lookup_widget(entry,"entry4");
combo1= lookup_widget(entry,"combobox1");
combo2= lookup_widget(entry,"combobox2");
taille= lookup_widget(entry,"entry5");
poids= lookup_widget(entry,"entry6");
  

  strcpy(a.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
  strcpy(a.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(a.taille,gtk_entry_get_text(GTK_ENTRY(taille)));
strcpy(a.poids,gtk_entry_get_text(GTK_ENTRY(poids)));
strcpy(a.sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo1)));
strcpy(a.choix_du_sport,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo2)));


  modifier_adh(a);
}


void
on_button21_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button22_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}

