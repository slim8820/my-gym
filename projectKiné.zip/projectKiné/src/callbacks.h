#include <gtk/gtk.h>


void
on_button1_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);



void
on_button17_clicked                    (GtkWidget       *objet_graphique17,
                                        gpointer         user_data);

void
on_button16_clicked                    (GtkWidget       *objet_graphique16,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkButton     *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void
on_button13_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer          user_data);
void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button15_clicked                    (GtkWidget       *objet_graphique15,
                                        gpointer         user_data);

void
on_button19_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button18_clicked                    (GtkWidget      *objet_graphique18,
                                        gpointer         user_data);

void
on_button20_clicked                    (GtkWidget      *objet_graphique20,
                                        gpointer         user_data);

void
on_button22_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button23_clicked                    (GtkButton       *button,
                                        gpointer         user_data);



void
on_button24_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button25_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button26_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button27_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button28_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button30_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button29_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button31_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_togglebutton1_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button32_leave                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button32_leave                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button33_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button35_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
void 

on_button34_clicked                      (GtkWidget       *objet_graphique,                        
                                          gpointer         user_data);
