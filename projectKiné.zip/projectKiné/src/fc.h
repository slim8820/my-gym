#include <gtk/gtk.h>
void ajouter(char nom[],char prenom[],char rdv[]);
void afficher();
int verifier(char login[],char password[]);

void modifier(char nom[],char prenom[],char rdv[]);
void afficher_rdv(GtkWidget *liste);
//void modifier1(char Nomk[],char Prenomk[],char Emailk[],char Date_de_naissancek[],char Numero_Tel[]);
//void afficher1_Perso(GtkWidget *liste);
