#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fc.h"
#include <gtk/gtk.h>


void ajouter(char nom[],char prenom[],char rdv[])
{
	FILE *f;
	f = fopen("rdv.txt","a+");
	if(f!=NULL){
		fprintf(f,"%s %s %s\n",nom,prenom,rdv);
}
	
	fclose(f);
}




void afficher()
{
	FILE *f;
	char login[20],password[20];

	f=fopen("users.txt","r");
	
	int role;
	while(fscanf(f,"%s %s %d", login, password, &role)!=EOF){
		printf("%s %s %d\n", login, password, role);
	}
	fclose(f);
}

int verifier(char login[],char password[])
{
        int ret=0;
	FILE *f;
	f=fopen("users.txt","r");
	
	char login1[20],password1[20];
	while(fscanf(f,"%s %s", login1, password1)!=EOF){
		if (strcmp(login1,login)==0 && strcmp(password1,password)==0)
		{
			ret=1;
		}
	}
	fclose(f);
	return ret;}
void afficher_rdv(GtkWidget *liste)
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;
enum   
{       
      
        NOM,
	PRENOM,
	RDV,
        COLUMNS
};
	char nom [30];
	char prenom [30];
	char rdv [30];
        store=NULL;

       FILE *f;
	
	store=gtk_tree_view_get_model(liste);	
	if (store==NULL)
	{

                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" Nom", renderer, "text",NOM, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" Prenom", renderer, "text",PRENOM, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);	
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  Rdv", renderer, "text",RDV, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	

               
	
	}

	
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,  G_TYPE_STRING, G_TYPE_STRING);

	f = fopen("rdv.txt", "r");
	
	if(f==NULL)
	{

		return;
	}		
	else 

	{ f = fopen("rdv.txt", "a+");
              while(fscanf(f,"%s %s %s \n",nom,prenom,rdv)!=EOF)
		{
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter, NOM, nom, PRENOM, prenom, RDV, rdv, -1); 
		}
		fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
    g_object_unref (store);
	}
}


void afficher1(GtkWidget *plistview)

{ 
enum { COL_NOM,
       COL_PRENOM,
       COL_SEANCEDECURE,
       NUM_COLS
      };
char nom[20],prenom[20],rdv[20];
GtkListStore *liststore;
GtkCellRenderer *celrender;
GtkTreeViewColumn *col;
liststore = gtk_list_store_new(NUM_COLS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
FILE *f;
f=fopen("rdv.txt","r");
if(f!=NULL){
       while(fscanf(f,"%s %s %s",nom,prenom,rdv)!=EOF){
           GtkTreeIter iter;
            gtk_list_store_append(liststore, &iter);
            gtk_list_store_set(liststore, &iter,
                          COL_NOM, nom,
		          COL_PRENOM, prenom,
		          COL_SEANCEDECURE, rdv,
                       -1);}
	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("nom",celrender,"text",COL_NOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("prenom",celrender,"text",COL_PRENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("rdv",celrender,"text",COL_SEANCEDECURE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);


	gtk_tree_view_set_model (GTK_TREE_VIEW(plistview), GTK_TREE_MODEL (liststore));

}
fclose(f);
}
void modifier(char nom[],char prenom[],char rdv[])
{    
    char nomk[20],prenomk[20],rdvk[20];
    FILE *f , *tmp;
    f=fopen("rdv.txt","r");
    tmp=fopen("rdv.tmp","a+");
    while(fscanf(f,"%s %s %s",nomk,prenomk,rdvk)!=EOF){
        if(!strcmp(nom,nomk) && !strcmp(prenom,prenomk)){fprintf(tmp,"%s %s %s\n",nom,prenom,rdv);}
else fprintf(tmp,"%s %s %s\n",nomk,prenomk,rdvk);
}
fclose(f);
fclose(tmp);
rename("rdv.tmp","rdv.txt");
}      

//void modifier1(char Nomk[],char Prenomk[],char Date_de_naissancek[],char Emailk[],char Numero_Telk[])
//{    
 //   char Nom[20],Prenom[20],Date_de_naissance[20],Email[20],Numero_Tel[20];
  //  FILE *f , *tmp;
  //  f=fopen("Perso.txt","r");
   // tmp=fopen("Perso.tmp","a+");
   // while(fscanf(f,"%s %s %s %s %s",Nomk,Prenomk,Date_de_naissancek,Emailk,Numero_Telk)!=EOF){
   //     if(!strcmp(Nom,Nomk) && !strcmp(Prenom,Prenomk)){fprintf(tmp,"%s %s %s %s %s\n",Nomk,Prenomk,Date_de_naissancek,Emailk,Numero_Telk);}
//else fprintf(tmp,"%s %s %s %s %s\n",Nomk,Prenomk,Date_de_naissancek,Emailk,Numero_Telk);
//}
//fclose(f);
//fclose(tmp);
//rename("Perso.tmp","Perso.txt");
//}      









