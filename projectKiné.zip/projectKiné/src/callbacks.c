#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fc.h"

void
on_button1_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
	int x=0;	
	GtkWidget *a ,*b,*c ,*window1,*window2;
	char login[20],password[20];
	
	window1= lookup_widget(objet_graphique,"window1");	
	a=lookup_widget(objet_graphique,"entry1");
	b=lookup_widget(objet_graphique,"entry2");
	c=lookup_widget(objet_graphique,"label5");
	strcpy(login,gtk_entry_get_text(GTK_ENTRY(a)));
	strcpy(password,gtk_entry_get_text(GTK_ENTRY(b)));
	x =verifier(login,password);
	
	if(x==1){
window2=create_window2();
gtk_widget_show (window2);
gtk_widget_hide(window1);
}
	else 
	{ gtk_label_set_text(GTK_LABEL(c),"authentification non validée");}
}


void
on_button17_clicked                    (GtkWidget       *objet_graphique17,
                                        gpointer         user_data)
{
GtkWidget *window2,*window3;
window2=lookup_widget(objet_graphique17,"window2");
window3=create_window3();
gtk_widget_show (window3);
gtk_widget_hide(window2);
}


void
on_button16_clicked                    (GtkWidget      *objet_graphique16,
                                        gpointer         user_data)
{
GtkWidget *window2,*window4;
window2=lookup_widget(objet_graphique16,"window2");
window4=create_window4();
gtk_widget_show (window4);
gtk_widget_hide(window2);

}


void
on_button3_clicked                     (GtkButton     *button,
                                        gpointer         user_data)
{
  //  GtkWidget *Nomk,*Prenomk,*Date_de_naissancek,*Emailk,*Numero_Telk, *window3,*window9,*List_View;
    //char Nom[20],Prenom[20],Date_de_naissance[20],Email[20],Numero_Tel[20];
    //Nomk=lookup_widget(objet_graphique,"entry14");
    //Prenomk=lookup_widget(objet_graphique,"entry15");
    //Date_de_naissancek=lookup_widget(objet_graphique,"entry16");
    //Emailk=lookup_widget(objet_graphique,"entry17");
    //Numero_Telk=lookup_widget(objet_graphique,"entry18");
    //strcpy(Nomk,gtk_entry_get_text(GTK_ENTRY(Nomk)));
    //strcpy(Prenomk,gtk_entry_get_text(GTK_ENTRY(Prenomk)));
    //strcpy(Date_de_naissancek,gtk_entry_get_text(GTK_ENTRY(Date_de_naissancek)));
    //strcpy(Emailk,gtk_entry_get_text(GTK_ENTRY(Emailk)));
    //strcpy(Numero_Telk,gtk_entry_get_text(GTK_ENTRY(Numero_Telk)));
    //modifier1(Nomk,Prenomk,Date_de_naissancek,Emailk,Numero_Telk);
    //afficher1_Perso(List_View);window3=create_window3();
    //window9=lookup_widget(objet_graphique,"window9");
    //gtk_widget_hide(window9);
    //List_View=lookup_widget(window3,"treeview1");
    //afficher_Perso(List_View);
    //gtk_widget_show (window3);

}


void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_button5_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *window5,*window4,*List_View;
window5=create_window5();
window4=lookup_widget(objet_graphique,"window4");
gtk_widget_hide(window4);
List_View=lookup_widget(window5,"treeview1");
afficher1(List_View);
gtk_widget_show (window5);
}

void
on_button13_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer          user_data)
{
GtkWidget *window8,*window4,*List_View;
window8=create_window8();
window4=lookup_widget(objet_graphique,"window4");
gtk_widget_hide(window4);
List_View=lookup_widget(window8,"treeview1");
afficher1(List_View);
gtk_widget_show (window8);
}

void
on_button6_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window8,*window4,*List_View;
window8=create_window8();
window4=lookup_widget(objet_graphique,"window4");
gtk_widget_hide(window4);
List_View=lookup_widget(window8,"treeview1");
afficher1(List_View);
gtk_widget_show (window8);

}


void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_button15_clicked                    (GtkWidget      *objet_graphique15,
                                        gpointer         user_data)
{
GtkWidget *window2,*window4;
window4=lookup_widget(objet_graphique15,"window4");
window2=create_window2();
gtk_widget_show (window2);
gtk_widget_hide(window4);
}


void
on_button19_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_button18_clicked                    (GtkWidget      *objet_graphique18,
                                        gpointer         user_data)
{
GtkWidget *window5,*window6;
window5=lookup_widget(objet_graphique18,"window5");
window6=create_window6();
gtk_widget_show (window6);
gtk_widget_hide(window5);
}


void
on_button20_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *a ,*b,*c ,*window5;
	char nom[20],prenom[20],rdv[20];
	
	a=lookup_widget(objet_graphique,"entry7");
	b=lookup_widget(objet_graphique,"entry8");
	c=lookup_widget(objet_graphique,"entry9");
	strcpy(nom,gtk_entry_get_text(GTK_ENTRY(a)));
	strcpy(prenom,gtk_entry_get_text(GTK_ENTRY(b)));
        strcpy(rdv,gtk_entry_get_text(GTK_ENTRY(c)));
        ajouter(nom,prenom,rdv);
}


void
on_button22_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window5,*window6,*List_View;
window5=create_window5();
window6=lookup_widget(objet_graphique,"window6");
gtk_widget_hide(window6);
List_View=lookup_widget(window5,"treeview1");
afficher1(List_View);
gtk_widget_show (window5);
}


void
on_button23_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_main_quit();
}







void
on_button24_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window2,*window3,*List_view;
window2=create_window2();
window3=lookup_widget(objet_graphique,"window3");
gtk_widget_hide(window3);
List_view=lookup_widget(window2,"treeview1");
afficher1(List_view);
gtk_widget_show (window2);

}


void
on_button25_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window4,*window5,*List_view;
window4=create_window4();
window5=lookup_widget(objet_graphique,"window5");
gtk_widget_hide(window5);
List_view=lookup_widget(window4,"treeview1");
afficher1(List_view);
gtk_widget_show (window4);
}




void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
    GtkWidget *nomk,*prenomk,*rdvk,*window7;
    gchar *nom,*prenom,*rdv;
    window7=create_window7();
    nomk=lookup_widget(window7,"entry11");
    prenomk=lookup_widget(window7,"entry12");
    rdvk=lookup_widget(window7,"entry13");
    GtkTreeIter iter;
    GtkTreeModel *model=gtk_tree_view_get_model (treeview);
    gtk_tree_model_get_iter(model,&iter,path);
    gtk_tree_model_get (model,&iter,0,&nom,1,&prenom,2,&rdv,-1);
    printf("%s %s %s ",nom,prenom,rdv);
    gtk_entry_set_text(GTK_ENTRY (nomk),_(nom));
    gtk_entry_set_text(GTK_ENTRY (prenomk),_(prenom));
    gtk_entry_set_text(GTK_ENTRY (rdvk),_(rdv));
    gtk_widget_show(window7);
}

void 
on_button26_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
    GtkWidget *nomk,*prenomk,*rdvk, *window5,*window7,*List_View;
    char nom[20],prenom[20],rdv[20];
    nomk=lookup_widget(objet_graphique,"entry11");
    prenomk=lookup_widget(objet_graphique,"entry12");
    rdvk=lookup_widget(objet_graphique,"entry13");
    strcpy(nom,gtk_entry_get_text(GTK_ENTRY(nomk)));
    strcpy(prenom,gtk_entry_get_text(GTK_ENTRY(prenomk)));
    strcpy(rdv,gtk_entry_get_text(GTK_ENTRY(rdvk)));
    modifier(nom,prenom,rdv);
    afficher_rdv(List_View);window5=create_window5();
    window7=lookup_widget(objet_graphique,"window7");
    gtk_widget_hide(window7);
    List_View=lookup_widget(window5,"treeview1");
    afficher_rdv(List_View);
    gtk_widget_show (window5);
   
}


void
on_button27_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window5,*window6,*List_view;
window5=create_window5();
window6=lookup_widget(objet_graphique,"window6");
gtk_widget_hide(window6);
List_view=lookup_widget(window5,"treeview1");
afficher1(List_view);
gtk_widget_show (window5);

}


void
on_button28_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window5,*window7,*List_view;
window5=create_window5();
window7=lookup_widget(objet_graphique,"window7");
gtk_widget_hide(window7);
List_view=lookup_widget(window5,"treeview1");
afficher1(List_view);
gtk_widget_show (window5);

}


void
on_button30_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button29_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button31_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window4,*window8,*List_view;
window4=create_window4();
window8=lookup_widget(objet_graphique,"window8");
gtk_widget_hide(window8);
List_view=lookup_widget(window4,"treeview1");
afficher1(List_view);
gtk_widget_show (window4);
}


void
on_togglebutton1_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button32_leave                      (GtkButton       *button,
                                        gpointer         user_data)
{

}





void
on_button33_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_main_quit();
}

void
on_button34_clicked                      (GtkWidget       *objet_graphique,                        
                                          gpointer         user_data)
{
GtkWidget *window4,*window8;
window8=lookup_widget(objet_graphique,"window8");
window4=create_window4();
gtk_widget_show (window4);
gtk_widget_hide(window8);
}
void
on_button35_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}

