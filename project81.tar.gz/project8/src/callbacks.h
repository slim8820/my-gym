#include <gtk/gtk.h>


void
on_affgha_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_affrdvgha_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_affrdvmed_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_supp_clicked                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_reclamation_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_modifiermdp_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_enregistrer_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_enregistrer1_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_affichermed_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_affichersuivi_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_rdv_staff_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_supp_rec_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_retourgh1_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_retourgh2_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
