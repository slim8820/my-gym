#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "adh.h"


void
on_affgha_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *treeview1;
treeview1=lookup_widget(objet_graphique,"treeview1");
afficher_emploi(treeview1);

}
		



void
on_affrdvgha_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
treeview1=lookup_widget(objet_graphique,"treeview4");
afficher_rdvcoach(treeview1);

}


void
on_affrdvmed_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

}


void
on_supp_clicked                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1,*window3;
window3 = create_window2 (); 
gtk_widget_show (window3);
      window1=lookup_widget(objet_graphique,"window1");
      gtk_widget_hide (window1);

}


void
on_reclamation_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
int test;
char id[10];
char rec[20];
char sujet[50];
GtkWidget *input1;
GtkWidget *combobox1;
GtkWidget *input2;
GtkWidget *output;

output= lookup_widget(objet_graphique,"firas") ;
input1=lookup_widget(objet_graphique,"entry37");
combobox1=lookup_widget(objet_graphique,"comboboxentry1");
input2=lookup_widget(objet_graphique,"entry32");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(sujet,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(rec,gtk_entry_get_text(GTK_ENTRY(input2)));


if (strlen(rec)==0)
gtk_label_set_text(GTK_LABEL(output),"aucune reclamation") ; 
else{
test=ajouter_recla(id,sujet,rec, &test) ;}
if (test==1)
{
gtk_label_set_text(GTK_LABEL(output),"Envoyée") ;
gtk_entry_set_text(GTK_ENTRY(input1),""); 
gtk_entry_set_text(GTK_ENTRY(input2),"");
}

}


void
on_modifiermdp_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
      GtkWidget *window1,*ghassen;
      GtkWidget *input1 , *input2, *output,*output1;
      char id1[10], psw1[10], id[10], psw[10];
      FILE *f;
      int x;
ghassen = create_ghassen (); 
      input1=lookup_widget(objet_graphique,"entry33");   
      input2=lookup_widget(objet_graphique,"entry34");
      output=lookup_widget(objet_graphique,"label65");
      output1=lookup_widget(ghassen,"entry35");
      strcpy(id1,gtk_entry_get_text(GTK_ENTRY(input1)));
      strcpy(psw1,gtk_entry_get_text(GTK_ENTRY(input2)));
      x=recherche(id1,psw1);
if (x==1)
{
f=fopen("/home/ghassen/Projects/project8/src/users.txt","r+");
if (f!=NULL)
{
while (fscanf(f,"%s %s \n",id,psw)!=EOF)
{
if ((strcmp(id,id1)==0)&&(strcmp(psw,psw1)==0));
{
      
      window1=lookup_widget(objet_graphique,"window1");
      gtk_widget_show (ghassen);
      gtk_widget_hide (window1);
      gtk_entry_set_text(GTK_ENTRY(output1),id1);  
break;         
}
}
fclose(f);
}
}
else 
{     
 gtk_label_set_text(GTK_LABEL(output),"Identifiant ou mot de passe incorrect");
}

}


void
on_enregistrer_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

}


void
on_enregistrer1_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *output, *input1 , *input2;
GtkWidget *window2;
char id[10], psw[10];
window2=create_ghassen();
input1=lookup_widget(objet_graphique,"entry35");
input2=lookup_widget(objet_graphique,"entry36"); 
output=lookup_widget(objet_graphique,"label71");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(psw,gtk_entry_get_text(GTK_ENTRY(input2))); 
modifiermot(id,psw);
gtk_label_set_text(GTK_LABEL(output),"Mot de passe est modifié avec succés");

}


void
on_affichermed_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
treeview1=lookup_widget(objet_graphique,"treeview2");
afficher_med(treeview1);


}


void
on_affichersuivi_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
treeview1=lookup_widget(objet_graphique,"treeview3");
afficher_suivi(treeview1);

}


void
on_rdv_staff_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
treeview1=lookup_widget(objet_graphique,"treeview5");
afficher_rdvstaff(treeview1);

}



void
on_supp_rec_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1, *output;
char id[20];
int x;
input1=lookup_widget(objet_graphique,"entry38");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(input1))); 
output=lookup_widget(objet_graphique,"label79");
x=recherche_rec(id);
if(x==1)
{
supprimer_rec(id); 
gtk_label_set_text(GTK_LABEL(output),"votre réclamation a été supprimée avec succés");
}
else 
{
gtk_label_set_text(GTK_LABEL(output),"identifiant non existant");
}

}


void
on_retourgh1_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1,*window2;
window1 = create_window1 (); 
gtk_widget_show (window1);

      window2=lookup_widget(objet_graphique,"ghassen");
      gtk_widget_hide (window2);
}


void
on_retourgh2_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1,*window2;
window1 = create_window1 (); 
gtk_widget_show (window1);
      window2=lookup_widget(objet_graphique,"window2");
      gtk_widget_hide (window2);
}

