#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "adh.h"

int recherche(char id[10],char psw[10])
{
int test=0;
FILE*f;
char id1[10],psw1[10];
f=fopen("/home/ghassen/Projects/project8/src/users.txt","r");
if (f!=NULL)
{
while (fscanf(f,"%s %s \n",id1,psw1)!=EOF)
{
   if ((strcmp(id,id1)==0)&&(strcmp(psw,psw1)==0))
   {
   test=1;
   break;
 
   }
}
fclose(f);
}
if (test==0)
{return 0;}
else 
{return 1;}
}

void modifiermot(char id[10], char psw[10])
{
char id1[10],psw1[10];
FILE *f, *f1;
f1=NULL;
f=fopen("/home/ghassen/Projects/project8/src/users.txt","r+");
f1=fopen("/home/ghassen/Projects/project8/src/users1.txt","w+");
if (f!=NULL)
{
while (fscanf(f,"%s %s \n",id1,psw1)!=EOF)
 {

            if(strcmp(id,id1)!=0)
            {
                fprintf(f1,"%s %s \n",id1,psw1);

            }
            else
            {
              
             fprintf(f1,"%s %s \n",id,psw);

            }
   }
    fclose(f1);
    fclose(f);

     remove("/home/ghassen/Projects/project8/src/users.txt");
     rename("/home/ghassen/Projects/project8/src/users1.txt","/home/ghassen/Projects/project8/src/users.txt");   
}
}
int ajouter_recla(char id[10],char sujet[],char rec[], int *test)
{
	FILE * f;
	*test =0;
	f=fopen("/home/ghassen/Projects/project8/src/reclamations.txt","a");
	if (f!=NULL) { 
	fprintf(f,"%s %s %s\n",id,sujet,rec);
	fclose(f);
	*test = 1 ;}
	return *test;
	
}

void afficher_emploi(GtkWidget *treeview2)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;
	 char lundi[20],mardi[20],mercredi[20],jeudi[20],vendredi[20],samedi[20],dimanche[20],id[20] ;

 
	FILE *f;


	store=NULL;
	
	//creat the colomns if they dont alredy exist
	store=gtk_tree_view_get_model(treeview2);	
	if (store==NULL)
	{

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Lundi", renderer,"text",Lundi, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);	
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Mardi", renderer, "text",Mardi, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);
                

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Mercredi", renderer, "text",Mercredi, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);
			

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Jeudi", renderer, "text",Jeudi, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Vendredi", renderer, "text",Vendredi, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Samedi", renderer, "text",Samedi, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Dimanche", renderer, "text",Dimanche, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);
		
		

	}
		store=gtk_list_store_new (7, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING , G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f = fopen("/home/ghassen/Projects/project8/src/emploi.txt", "r");
	
	if(f ==NULL)
	{

		return;
	}		
	else
	{
	
		while(fscanf(f,"%s %s %s %s %s %s %s %s",lundi,mardi,mercredi,jeudi,vendredi,samedi,dimanche ,id)!=EOF)
		{
			gtk_list_store_append (store, &iter);
			gtk_list_store_set (store, &iter,Lundi,lundi,Mardi,mardi,Mercredi,mercredi,Jeudi,jeudi,Vendredi,vendredi,Samedi,samedi,Dimanche,dimanche,-1);
		}
		
		fclose(f);
		
	}
		
	gtk_tree_view_set_model (GTK_TREE_VIEW (treeview2), GTK_TREE_MODEL (store));
	
	g_object_unref (store);
	
}



void afficher_med(GtkWidget *treeview2)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;
	 char lundi[20],mardi[20],mercredi[20],jeudi[20],vendredi[20],samedi[20],lundi1[20],mardi1[20],mercredi1[20],jeudi1[20],id[20];

 
	FILE *f;


	store=NULL;
	
	//creat the colomns if they dont alredy exist
	store=gtk_tree_view_get_model(treeview2);	
	if (store==NULL)
	{

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Nom", renderer,"text",Nom, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);	
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Prenom", renderer, "text",Prenom, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);
                

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Sexe", renderer, "text",Sexe, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);
			

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Age", renderer, "text",Age, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Poids", renderer, "text",Poids, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Taille", renderer, "text",Taille, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Regime", renderer, "text",Regime, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Maladie", renderer, "text",Maladie, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Allergie", renderer, "text",Allergie, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Notice", renderer, "text",Notice, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);

		
		

	}
		store=gtk_list_store_new (10, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING , G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f = fopen("/home/ghassen/Projects/project8/src/fichemed.txt", "r");
	
	if(f ==NULL)
	{

		return;
	}		
	else
	{
	
		while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s",lundi,mardi,mercredi,jeudi,vendredi,samedi,lundi1,mardi1,mercredi1,jeudi1,id)!=EOF)
		{
			gtk_list_store_append (store, &iter);
			gtk_list_store_set (store, &iter,Nom,lundi,Prenom,mardi,Sexe,mercredi,Age,jeudi,Poids,vendredi,Taille,samedi,Regime,lundi1,Maladie,mardi1,Allergie,mercredi1,Notice,jeudi1,-1);
		}
		
		fclose(f);
		
	}
		
	gtk_tree_view_set_model (GTK_TREE_VIEW (treeview2), GTK_TREE_MODEL (store));
	
	g_object_unref (store);
	
}


void afficher_suivi(GtkWidget *treeview2)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;
	 char lundi[20],mardi[20],mercredi[20],jeudi[20],vendredi[20],samedi[20],lundi1[20],mardi1[20],mercredi1[20],id[20] ;

 
	FILE *f;


	store=NULL;
	
	//creat the colomns if they dont alredy exist
	store=gtk_tree_view_get_model(treeview2);	
	if (store==NULL)
	{

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Nom", renderer,"text",Nom1, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);	
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Prenom", renderer, "text",Prenom1, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);
                

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Sexe", renderer, "text",Sexe1, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);
			

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Age", renderer, "text",Age1, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Type d'activité", renderer, "text",Type, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Heure", renderer, "text",H, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Date", renderer, "text",D, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);

		
		

	}
		store=gtk_list_store_new (7, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING , G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f = fopen("/home/ghassen/Projects/project8/src/suivi.txt", "r");
	
	if(f ==NULL)
	{

		return;
	}		
	else
	{
	
		while(fscanf(f,"%s %s %s %s %s %s %s %s",lundi,mardi,mercredi,jeudi,vendredi,samedi ,lundi1,id)!=EOF)
		{
			gtk_list_store_append (store, &iter);
			gtk_list_store_set (store, &iter,Nom1,lundi,Prenom1,mardi,Sexe1,mercredi,Age1,jeudi,Type,vendredi,H,samedi,D,lundi1,-1);
		}
		
		fclose(f);
		
	}
		
	gtk_tree_view_set_model (GTK_TREE_VIEW (treeview2), GTK_TREE_MODEL (store));
	
	g_object_unref (store);
	
}

void afficher_rdvcoach(GtkWidget *treeview2)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;
	 char lundi[20],mardi[20],mercredi[20] , jeudi[20] , vendredi[20], samedi[20] ;

 
	FILE *f;


	store=NULL;
	
	//creat the colomns if they dont alredy exist
	store=gtk_tree_view_get_model(treeview2);	
	if (store==NULL)
	{

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Nom", renderer,"text",Nom3, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);
		renderer = gtk_cell_renderer_text_new ();

		column = gtk_tree_view_column_new_with_attributes("Prenom", renderer,"text",Prenom3, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Heure", renderer, "text",Heure, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);

                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Jour", renderer, "text",Date, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);
	
                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Mois", renderer, "text",jour, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);

                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Annee", renderer, "text",annee, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);
                

	
		

	}
		store=gtk_list_store_new (6, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f = fopen("/home/ghassen/Projects/project8/src/rdvstaff.txt", "r");
	
	if(f ==NULL)
	{

		return;
	}		
	else
	{
	
		while(fscanf(f,"%s %s %s %s %s %S ",lundi,mardi,mercredi,jeudi,vendredi,samedi)!=EOF)
		{
			gtk_list_store_append (store, &iter);
			gtk_list_store_set (store, &iter,Nom3,lundi,Prenom3,mardi,Heure,mercredi,Date,jeudi,jour,vendredi,annee,samedi,-1);
		}
		
		fclose(f);
		
	}
		
	gtk_tree_view_set_model (GTK_TREE_VIEW (treeview2), GTK_TREE_MODEL (store));
	
	g_object_unref (store);
	
}


void  afficher_rdvstaff(GtkWidget *treeview2)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;
	 char lundi[20],mardi[20],mercredi[20] , jeudi[20] , vendredi[20], samedi[20] ;

 
	FILE *f;


	store=NULL;
	
	//creat the colomns if they dont alredy exist
	store=gtk_tree_view_get_model(treeview2);	
	if (store==NULL)
	{

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Nom", renderer,"text",Nom4, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Prenom", renderer,"text",Prenom4, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Heure", renderer, "text",Heure4, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);

                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Jour", renderer, "text",Date4, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);

		
                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Mois", renderer, "text",jour4, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);

                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Annee", renderer, "text",annee4, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);


	
		

	}
		store=gtk_list_store_new (6, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f = fopen("/home/ghassen/Projects/project8/src/rdvcoach.txt", "r");
	
	if(f ==NULL)
	{

		return;
	}		
	else
	{
	
		while(fscanf(f,"%s %s %s %s %s %s",lundi,mardi,mercredi,jeudi,vendredi,samedi)!=EOF)
		{
			gtk_list_store_append (store, &iter);
			gtk_list_store_set (store, &iter,Nom4,lundi,Prenom4,mardi,Heure4,mercredi,Date4,jeudi,jour4,vendredi,annee4,samedi,-1);
		}
		
		fclose(f);
		
	}
		
	gtk_tree_view_set_model (GTK_TREE_VIEW (treeview2), GTK_TREE_MODEL (store));
	
	g_object_unref (store);
	
}





void supprimer_rec(char id1[10])
{
FILE *f, *f1;
char id[10];
char sujet[50];
char rec[200];
f1=NULL;
f=fopen("/home/ghassen/Projects/project8/src/reclamations.txt","r");

 if (f==NULL)
{
return;
} 
     while (fscanf(f,"%s %s %s \n",id,sujet,rec)!=EOF)
{
    if (strcmp(id,id1))
{  f1=fopen("/home/ghassen/Projects/project8/src/reclamations1.txt","a+");
  fprintf(f1,"%s %s %s\n",id,sujet,rec);

fclose(f1);
}

}
fclose(f);
 remove("/home/ghassen/Projects/project8/src/reclamations.txt");
 rename("/home/ghassen/Projects/project8/src/reclamations1.txt","/home/ghassen/Projects/project8/src/reclamations.txt");
}






int recherche_rec(char id1[10])
{
int test=0;
char id[10];
char sujet[50];
char rec[200];
FILE*f;
f=fopen("/home/ghassen/Projects/project8/src/reclamations.txt","r+");
if (f!=NULL)
{
     while (fscanf(f,"%s %s %s \n",id,sujet,rec)!=EOF)
{
   if (strcmp(id,id1)==0)
   {test=1;
   break;
   return 1;
   }
}
fclose(f);
}
if (test==0)
{return 0;}
else 
{return 1;}
}





