#include <gtk/gtk.h>
typedef struct adh
{	
	char mdp[20];
	char ident[20];
	
}adh;

enum
{
Lundi,
Mardi,
Mercredi,
Jeudi,
Vendredi,
Samedi,
Dimanche,
NUM_COLS,
} ;
enum
{
Nom,
Prenom,
Sexe,
Age,
Poids,
Taille,
Regime,
Maladie,
Allergie,
Notice,
} ;
enum
{
Nom1,
Prenom1,
Sexe1,
Age1,
Poids1,
Type,
H,
D,
};
enum
{
Nom3,
Prenom3,
Heure,
Date,
jour,
annee,
};
enum
{
Nom4,
Prenom4,
Heure4,
Date4,
jour4,
annee4,
};

void afficher_emploi(GtkWidget *treeview2);
void afficher_med(GtkWidget *treeview2);
void afficher_suivi(GtkWidget *treeview2);
void afficher_rdvstaff(GtkWidget *treeview2);
void afficher_rdvcoach(GtkWidget *treeview2);


int recherche(char id[10],char psw[10]);
void modifiermot(char id[10], char psw[10]);
int ajouter_recla(char id[10], char sujet[],char rec[], int *test);
void supprimer_rec(char id[10]);
int recherche_rec(char id[10]);

